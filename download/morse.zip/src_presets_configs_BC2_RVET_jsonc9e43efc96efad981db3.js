"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_configs_BC2_RVET_json"],{

/***/ "./src/presets/configs/BC2_RVET.json":
/*!*******************************************!*\
  !*** ./src/presets/configs/BC2_RVET.json ***!
  \*******************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"morseSettings":[{"key":"wpm","value":24,"comment":null},{"key":"fwpm","value":10,"comment":null},{"key":"preSpace","value":"0","comment":null},{"key":"xtraWordSpaceDits","value":"1","comment":null},{"key":"volume","value":"7","comment":null},{"key":"stickySets","value":"BK","comment":null},{"key":"ifStickySets","value":false,"comment":null},{"key":"syncWpm","value":false,"comment":null},{"key":"hideList","value":true,"comment":null},{"key":"showRaw","value":false,"comment":null},{"key":"autoCloseLessonAccordian","value":false,"comment":null},{"key":"cardFontPx","value":"15","comment":null},{"key":"customGroup","value":"","comment":null},{"key":"showExpertSettings","value":"true","comment":null},{"key":"voiceEnabled","value":true,"comment":null},{"key":"voiceSpelling","value":true,"comment":null},{"key":"voiceThinkingTime","value":0,"comment":null},{"key":"voiceAfterThinkingTime","value":0,"comment":null},{"key":"voiceVolume","value":10,"comment":null},{"key":"voiceLastOnly","value":false,"comment":null},{"key":"voiceRecap","value":true,"comment":null},{"key":"keepLines","value":false,"comment":null},{"key":"syncSize","value":false,"comment":null},{"key":"overrideSize","value":true,"comment":null},{"key":"overrideSizeMin","value":"3","comment":null},{"key":"overrideSizeMax","value":"3","comment":null},{"key":"cardSpace","value":0,"comment":"AKA cardWait"},{"key":"hapticAccordionOpen","value":"false","comment":null},{"key":"miscSettingsAccordionOpen","value":"true","comment":null},{"key":"speedInterval","value":true,"comment":null},{"key":"intervalTimingsText","value":"30,30,30,30","comment":null},{"key":"intervalWpmText","value":"12","comment":null},{"key":"intervalFwpmText","value":"12, 11, 10, 8","comment":null},{"key":"voiceBufferMaxLength","value":"1","comment":null},{"key":"speakFirst","value":false,"comment":null},{"key":"speakFirstRepeats","value":0,"comment":null},{"key":"speakFirstAdditionalWordspaces","value":0,"comment":null}]}');

/***/ })

}]);